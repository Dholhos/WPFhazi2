﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void sliRed_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            byte red, green, blue;
            red = Convert.ToByte(sliRed.Value);
            green = Convert.ToByte(sliGreen.Value);
            blue = Convert.ToByte(sliBlue.Value);
            rctColor.Fill = new SolidColorBrush(Color.FromRgb(red, green, blue));

            labRed.Content = Math.Floor(sliRed.Value);
        }

        private void sliGreen_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            byte red, green, blue;
            red = Convert.ToByte(sliRed.Value);
            green = Convert.ToByte(sliGreen.Value);
            blue = Convert.ToByte(sliBlue.Value);
            rctColor.Fill = new SolidColorBrush(Color.FromRgb(red, green, blue));

            labGreen.Content = Math.Floor(sliGreen.Value);
        }

        private void sliBlue_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            byte red, green, blue;
            red = Convert.ToByte(sliRed.Value);
            green = Convert.ToByte(sliGreen.Value);
            blue = Convert.ToByte(sliBlue.Value);
            rctColor.Fill = new SolidColorBrush(Color.FromRgb(red, green, blue));

            labBlue.Content = Math.Floor(sliBlue.Value);
        }

        private void btnRogzit_Click_1(object sender, RoutedEventArgs e)
        {
            double red, green, blue;
            red = Math.Floor(Convert.ToDouble(sliRed.Value));
            green =Math.Floor(Convert.ToDouble(sliGreen.Value));
            blue = Math.Floor(Convert.ToDouble(sliBlue.Value));
            string szinAdatok = $"{red} {green} {blue}";

            if (lbSzinek.Items.Contains(szinAdatok))
            {
                MessageBox.Show("Ez a RGB kombináció már szerepel a listában");
            }
            else
            {
                lbSzinek.Items.Add(szinAdatok);
            }
        }

        private void btnTorol_Click(object sender, RoutedEventArgs e)
        {
           if(lbSzinek.SelectedIndex == -1)
            {
                MessageBox.Show("Jeloljön ki elemet!");
            }
            else
            {
                lbSzinek.Items.RemoveAt(lbSzinek.SelectedIndex);
            }
        }

        private void btnUrit_Click(object sender, RoutedEventArgs e)
        {
            if(lbSzinek.Items.Count == 0)
            {
                MessageBox.Show("A lista már üres!");
            }
            else
            {
                lbSzinek.Items.Clear();
            }
        }

        private void lbSzinek_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            double red, green, blue;
            red = Math.Floor(Convert.ToDouble(sliRed.Value));
            green = Math.Floor(Convert.ToDouble(sliGreen.Value));
            blue = Math.Floor(Convert.ToDouble(sliBlue.Value));
            red = green;
            green = blue;
            blue = red;
        }

        private void lbSzinek_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string[] tagok = lbSzinek.SelectedItem.ToString().Split(';');
            sliRed.Value = Convert.ToDouble(tagok[0]);
            sliGreen.Value = Convert.ToDouble(tagok[1]);
            sliBlue.Value = Convert.ToDouble(tagok[2]);
        }
    }
}
